package com.crud.librarysystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.crud.librarysystem.entity.ReservationEntity;
import com.crud.librarysystem.service.ReservationService;

@RestController
@RequestMapping(method=RequestMethod.GET, path="/reservation/api")
@CrossOrigin
public class ReservationController {
    @Autowired
    ReservationService rserv;
    
    public ReservationController() {
    }
    
    @GetMapping("/printTitle")
    public String displayTitle() {
        return "Library System Reservation";
    }
    
    //CREATE
    @PostMapping("/postNewReservation")
    public ReservationEntity postReservation(@RequestBody ReservationEntity reservation) {
        return rserv.postReservation(reservation);
    }
    
    //READ
    @GetMapping("/getAllReservations")
    public List<ReservationEntity> getAllReservations(){
        return rserv.getAllReservations();
    }
    
    @GetMapping("/getByStatus")
    public ReservationEntity getReservationByStatus(@RequestParam String status) throws Exception{
        return rserv.getReservationByStatus(status);
    }
    
    //UPDATE
    @PutMapping("/putReservation")
    public ReservationEntity putReservation(@RequestParam int id, @RequestBody ReservationEntity newReservationDetails) {
        return rserv.putReservation(id, newReservationDetails);
    }
    
    //DELETE
    @DeleteMapping("/deleteReservation/{id}")
    public String deleteReservation(@PathVariable int id) {
        return rserv.deleteReservation(id);
    }
}