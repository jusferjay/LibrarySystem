package com.crud.librarysystem.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud.librarysystem.entity.BorrowEntity;
import com.crud.librarysystem.repository.BorrowRepository;

@Service
public class BorrowService {
    @Autowired
    BorrowRepository wrepo;
    
    public BorrowService() {
    }
    
    //CREATE
    public BorrowEntity postBorrowing(BorrowEntity borrowing) {
        return wrepo.save(borrowing);
    }
    
    //READ
    public List<BorrowEntity> getAllBorrowings(){
        return wrepo.findAll();
    }
    public BorrowEntity findByBorrowDate(LocalDate borrowDate) throws Exception{
        if(wrepo.findByBorrowDate(borrowDate)!=null) 
		return wrepo.findByBorrowDate(borrowDate);
	else 
		throw new Exception("There is no borrowed books that has an id" + borrowDate + " in the list");
    }
    
    
    //UPDATE
    @SuppressWarnings("finally")
	public BorrowEntity putBorrowing(int id, BorrowEntity newBorrowDetails) {
        BorrowEntity borrowing = new BorrowEntity();
        try {
            borrowing = wrepo.findById(id).get();
            borrowing.setBorrowDate(newBorrowDetails.getBorrowDate());
            borrowing.setDueDate(newBorrowDetails.getDueDate());
        } catch(Exception ex) {
            throw new Exception("Borrowing " + id + " does not exist!");
        } finally {
            return wrepo.save(borrowing);
        }
    }
    
    //DELETE
    public String deleteBorrowing(int id) {
        String msg = "";
        wrepo.deleteById(id);
		msg = "Borrowing " + id + " is successfully deleted!";
        return msg;
    }
}