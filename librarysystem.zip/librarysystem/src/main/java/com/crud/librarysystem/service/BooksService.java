package com.crud.librarysystem.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.crud.librarysystem.entity.BooksEntity;
import com.crud.librarysystem.repository.BooksRepository;

@Service
public class BooksService {
@Autowired
BooksRepository brepo;

public BooksService() {
	
}
//CREATE 
public BooksEntity postBooks(BooksEntity books) {
	return brepo.save(books);
}

//READ
public List<BooksEntity>getAllBooks(){
	return brepo.findAll();
}
public BooksEntity getBooksByTitle(String title) throws Exception {
	if(brepo.findByTitle(title)!=null) 
		return brepo.findByTitle(title);
	else 
		throw new Exception("There is no books that is titled" + title + " in the list");
	
}

//UPDATE
@SuppressWarnings("finally")
public BooksEntity putBooks(int bookid, BooksEntity newBooksDetails) {
	BooksEntity books = new BooksEntity();
	
	try {
		books = brepo.findById(bookid).get();
		books.setTitle(newBooksDetails.getTitle());
		books.setAuthor(newBooksDetails.getAuthor());
		books.setStatus(newBooksDetails.getStatus());
	}catch(Exception ex) {
		throw new Exception("There is no books with the id" + bookid + " in the system!");
	}finally {
		return brepo.save(books);
	}
}

//DELETE
public String deleteBooks(int bookid) {
	String msg = "";
	brepo.deleteById(bookid);
	msg = "Book " + bookid + " is successfully deleted!";
	return msg;
}

@ExceptionHandler
public ResponseEntity<ErrorResponse>handleException(Exception ex){
	ErrorResponse error = new ErrorResponse();
	
	error.setStatus(HttpStatus.BAD_REQUEST.value());
	error.setMessage(ex.getMessage());
	error.setTimestamp(System.currentTimeMillis());
	
	return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
}
}