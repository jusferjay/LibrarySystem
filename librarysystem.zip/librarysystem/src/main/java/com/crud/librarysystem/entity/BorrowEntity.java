package com.crud.librarysystem.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="borrow")
public class BorrowEntity {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int borrowid;
    private LocalDate borrowDate;
    private LocalDate dueDate;
    
    public BorrowEntity() {
    }
    
    public BorrowEntity(int borrowid, LocalDate borrowDate, LocalDate dueDate) {
        super();
        this.borrowid = borrowid;
        this.borrowDate = borrowDate;
        this.dueDate = dueDate;
    }
    
    public int getBorrowid() {
        return borrowid;
    }
    
    public void setBorrowid(int borrowid) {
        this.borrowid = borrowid;
    }
    
    public LocalDate getBorrowDate() {
        return borrowDate;
    }
    
    public void setBorrowDate(LocalDate borrowDate) {
        this.borrowDate = borrowDate;
    }
    
    public LocalDate getDueDate() {
        return dueDate;
    }
    
    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }
}