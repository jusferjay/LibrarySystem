package com.crud.librarysystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.crud.librarysystem.entity.BooksEntity;
import com.crud.librarysystem.service.BooksService;

import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
@RequestMapping(method=RequestMethod.GET,path="/books/api")
@CrossOrigin
public class BooksController {
@Autowired
BooksService bserv;

public BooksController() {
	
}

@GetMapping("/printTitle")
public String displayTitle() {
	return "Library Borrowing System";
}

 //CREATE
@PostMapping("/postNewBook")
public BooksEntity postBooks(@RequestBody BooksEntity books) {
	return bserv.postBooks(books);
}

 //READ
@GetMapping("/getAllBooks")
public List<BooksEntity>getAllBooks(){
	return bserv.getAllBooks();
}

@GetMapping("/getByTitle")
public BooksEntity getbooksbyTitle(@RequestParam String title) throws Exception {
	return bserv.getBooksByTitle(title);
}

 //UPDATE
@PutMapping("/putBooks")
public BooksEntity putBooks(@RequestParam int bookid, @RequestBody BooksEntity newBooksDetails) {
	return bserv.putBooks(bookid, newBooksDetails);
}

 //DELETE
@DeleteMapping("/deleteBooks/{bookid}")
public String deleteBooks(@PathVariable int bookid) {
	return bserv.deleteBooks(bookid);
}
}