package com.crud.librarysystem.service;

public class ErrorResponse {


	public void setTimestamp(long timeMillis) {
		// TODO Auto-generated method stub
		
	}

	public void setMessage(String message) {
		// TODO Auto-generated method stub
		
	}

	public void setStatus(int value) {
		// TODO Auto-generated method stub
		
	}

}