package com.crud.librarysystem.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.crud.librarysystem.entity.BorrowEntity;
import com.crud.librarysystem.service.BorrowService;

@RestController
@RequestMapping(method=RequestMethod.GET, path="/borrow/api")
@CrossOrigin
public class BorrowController {
    @Autowired
    BorrowService wserv;
    
    public BorrowController() {
    }
    
    @GetMapping("/printTitle")
    public String displayTitle() {
        return "Library Borrowing System";
    }
    
    // CREATE
    @PostMapping("/postNewBorrow")
    public BorrowEntity postBorrowing(@RequestBody BorrowEntity borrow) {
        return wserv.postBorrowing(borrow);
    }
    
    // READ
    @GetMapping("/getAllBorrowedBooks")
    public List<BorrowEntity> getAllBorrowings(){
        return wserv.getAllBorrowings();
    }
    
   @GetMapping("/getBorrowDate/{borrowDate}")
    public BorrowEntity findByBorrowDate(@PathVariable LocalDate borrowDate) throws Exception{
        return wserv.findByBorrowDate(borrowDate);
    }
    
    // UPDATE
    @PutMapping("/putBorrow")
    public BorrowEntity putBorrowing(@RequestParam int borrowid, @RequestBody BorrowEntity newBorrowingDetails) {
        return wserv.putBorrowing(borrowid, newBorrowingDetails);
    }
    
    // DELETE
    @DeleteMapping("/deleteBorrow/{id}")
    public String deleteBorrowing(@PathVariable int borrowid) {
        return wserv.deleteBorrowing(borrowid);
    }
}