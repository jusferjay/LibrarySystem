package com.crud.librarysystem.entity;


import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="reservation")
public class ReservationEntity {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int reservationId;
    private LocalDateTime reservationDate;
    private String status;
    
    public ReservationEntity() {
    }
    
    public ReservationEntity(int reservationId, LocalDateTime reservationDate, String status) {
        super();
        this.reservationId = reservationId;
        this.reservationDate = reservationDate;
        this.status = status;
    }
    
    public int getReservationId() {
        return reservationId;
    }
    
    public void setReservationId(int reservationId) {
        this.reservationId = reservationId;
    }
    
    public LocalDateTime getReservationDate() {
        return reservationDate;
    }
    
    public void setReservationDate(LocalDateTime reservationDate) {
        this.reservationDate = reservationDate;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
}