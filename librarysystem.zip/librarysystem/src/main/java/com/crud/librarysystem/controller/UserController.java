package com.crud.librarysystem.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.crud.librarysystem.entity.UserEntity;
import com.crud.librarysystem.service.UserService;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;



@RestController
@RequestMapping(method=RequestMethod.GET,path="/users/api")
public class UserController {
    @Autowired
    UserService userv;

    public UserController(){

    }
    @GetMapping("/printName")
    public String displayName() {
        return "Library User";
    }

    //CREATE
    @PostMapping("/postNewUser")
    public UserEntity postUser(@RequestBody UserEntity user) {
        //TODO: process POST request
        
        return userv.postUser(user);
    }
    //READ 
    @GetMapping("/getAllUser")
    public List<UserEntity>getAllUser(){
        return userv.getAllUser();
    }
    @GetMapping("/getByUser")
    public UserEntity getUserByName(@RequestParam String name) throws Exception {
        return userv.getUserByName(name);
    }

    //UPDATE
    @PutMapping("/putUser")
    public UserEntity putUser(@RequestParam int userid, @RequestBody UserEntity newUserDetails){
        return userv.putUser(userid, newUserDetails);
    } 
     //DELETE
     @DeleteMapping("/deleteUser/{userid}")
     public String deleteUser(@PathVariable int userid){
        return userv.deleteUser(userid);
     }

}