package com.crud.librarysystem.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

@Entity
@Table(name="User")
public class UserEntity {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int userid;
    private String name;
    private String contactNumber;

    public UserEntity(){

    }

    public UserEntity(int userid, String name, String contactNumber){
        super();
        this.userid=userid;
        this.name=name;
        this.contactNumber=contactNumber;
    }

    public int getUserid(){
        return userid;
    }
    public void setUserid(int userid){
        this.userid = userid;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getContactNumber(){
        return contactNumber;
    }
    public void setContactNumber(String contactNumber){
        this.contactNumber = contactNumber;
    }

}