package com.crud.librarysystem.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.crud.librarysystem.entity.UserEntity;
import com.crud.librarysystem.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    UserRepository urepo;
    public UserService(){

    }
    //CREATE
    public UserEntity postUser(UserEntity user){
        return urepo.save(user);
    }
    //READ
    public List<UserEntity> getAllUser(){
        return urepo.findAll();
    }
    public UserEntity getUserByName(String name) throws Exception{
        if(urepo.findByName(name)!=null)
      return urepo.findByName(name);
      else
      throw new Exception("There is no User that is named" + name + " in the list");
      
    }
    //UPDATE
    @SuppressWarnings("finally")
    public UserEntity putUser(int userid, UserEntity newUserDetails){
        UserEntity user = new UserEntity();
        try{
            user = urepo.findById(userid).get();
            user.setName(newUserDetails.getName());
            user.setContactNumber(newUserDetails.getContactNumber());
        }catch(Exception ex){
            throw new Exception("There is no user with the id" + userid + " in the system.");
        }finally {
            return urepo.save(user);
        }
    }
    //DELETE
    public String deleteUser(int userid){
        String msg ="";
        urepo.deleteById(userid);
		msg = "User " + userid + " delete na mam";
        return msg;
    }
    
    @ExceptionHandler
    public ResponseEntity<ErrorResponse>handleException(Exception ex){
        ErrorResponse error= new ErrorResponse();
        
        error.setStatus(HttpStatus.BAD_REQUEST.value());
        error.setMessage(ex.getMessage());
        error.setTimestamp(System.currentTimeMillis());

        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }
    
}