package com.crud.librarysystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.crud.librarysystem.entity.ReservationEntity;
import com.crud.librarysystem.repository.ReservationRepository;

@Service
public class ReservationService {
    @Autowired
    ReservationRepository rrepo;
    
    public ReservationService() {
    }
    
    //CREATE
    public ReservationEntity postReservation(ReservationEntity reservation) {
        return rrepo.save(reservation);
    }
    
    //READ
    public List<ReservationEntity> getAllReservations(){
        return rrepo.findAll();
    }
    
    public ReservationEntity getReservationByStatus(String status) throws Exception {
        if (rrepo.findByStatus(status)!=null)
            return rrepo.findByStatus(status);
        else
            throw new Exception("There is no reservation with status " + status + " in the list.");
    }
    
    //UPDATE
    @SuppressWarnings("finally")
    public ReservationEntity putReservation(int id, ReservationEntity newReservationDetails) {
        ReservationEntity reservation = new ReservationEntity();
        try {
            reservation = rrepo.findById(id).get();
            reservation.setReservationDate(newReservationDetails.getReservationDate());
            reservation.setStatus(newReservationDetails.getStatus());
        }catch(Exception ex) {
            throw new Exception("Reservation " + id + " does not exist!");
        }finally {
            return rrepo.save(reservation);
        }
    }
    
    //DELETE
    public String deleteReservation(int id) {
        String msg = "";
        rrepo.deleteById(id);
		msg = "Reservation " + id + " is successfully deleted!";
        return msg;
    }
    
    @ExceptionHandler
    public ResponseEntity<ErrorResponse> handleException(Exception ex){
        ErrorResponse error = new ErrorResponse();
        error.setStatus(HttpStatus.NOT_FOUND.value());
        error.setMessage(ex.getMessage());
        error.setTimestamp(System.currentTimeMillis());
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }
}